﻿CREATE PROCEDURE [dbo].[dispCostomer]  
AS  
   BEGIN  
   SELECT * FROM Costomer
END