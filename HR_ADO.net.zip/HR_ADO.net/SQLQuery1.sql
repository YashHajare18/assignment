﻿CREATE PROCEDURE [dbo].[@Display]
AS
BEGIN
SELECT * FROM Employee
END